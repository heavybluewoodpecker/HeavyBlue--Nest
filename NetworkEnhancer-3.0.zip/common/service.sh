#!/system/bin/sh
# "Do more of what makes you happy."
# =============================================
# Author: (@RAAJK20Pro) Telegram :- https://t.me/Raphaelgamers
# ==============================================
# (https://github.com/RAAJK20Pro/NetworkEnhancer)
# ==============================================
# =============================================
# FAILSAFE CONFIGURATION
# =============================================
EMERGENCY_LOG="/data/local/tmp/NetworkEnhancer_emergency.log"
: > "$EMERGENCY_LOG"

# Error handler
error_handler() {
  line="$1"
  last_error="$2"
  {
    echo "[$(date '+%Y-%m-%d %I:%M %p')] 💥 CRASH at line $line"
    echo "Last error code: $last_error"
  } >> "$EMERGENCY_LOG"
}

# Catch any unexpected errors
trap 'error_handler $LINENO $?' ERR

timeout=150
while [ "$(getprop sys.boot_completed)" != "1" ] || [ ! -d /sdcard/Android ] || [ ! -w /sdcard ]; do
  sleep 2
  timeout=$((timeout - 2))
  if [ "$timeout" -le 0 ]; then
    echo "[$(date '+%Y-%m-%d %I:%M %p')] Boot timeout or /sdcard unavailable" >> "$EMERGENCY_LOG"
    exit 1
  fi
done
sleep 5
# =============================================
# LOGGING CONFIGURATION
# =============================================
LOG_FILE="/data/local/tmp/NetworkEnhancer.log"
SDCARD_LOG="/sdcard/NetworkEnhancer.log"

# Clear previous logs
: > "$LOG_FILE"
: > "$SDCARD_LOG"

exec 2>>"$LOG_FILE"

# Emoji Constants
SUCCESS="✅"
FAILED="❌"
UNSUPPORTED="🚫"
WARNING="⚠️"
NETWORK="🌐"
TCP="📡"
UDP="📶"
SECURITY="🔒"
MEMORY="🧠"

# Enhanced Logging
log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE" >> "$SDCARD_LOG"
}

RAAJK20Pro() {
  local path="$1"
  local value="$2"
  local description="$3"
  local emoji="$4"
  
  if [ ! -f "$path" ]; then
    log "$UNSUPPORTED $description (KERNEL NOT SUPPORTED)"
    return 2
  fi
  
  if ! echo "$value" > "$path" 2>>"$LOG_FILE"; then
    log "$FAILED $description (FAILED)"
    return 1
  fi
  
  log "$emoji $SUCCESS $description"
  return 0
}

(
  flock -n 9 || {

    exit 1
  }
  
# =============================================
# INITIALIZATION
# =============================================

log "=== 𝗡𝗲𝘁𝘄𝗼𝗿𝗸𝗘𝗻𝗵𝗮𝗻𝗰𝗲𝗿 ==="
log "Device: $(getprop ro.product.model)"
log "Android: $(getprop ro.build.version.release)"
log "Kernel: $(uname -a)"
log "Started at $(date)"
log ""

# =============================================
log "==== 𝗖𝗢𝗥𝗘 𝗡𝗘𝗧𝗪𝗢𝗥𝗞 𝗕𝗨𝗙𝗙𝗘𝗥𝗦 (𝗙𝗔𝗦𝗧𝗘𝗥 𝗣𝗔𝗖𝗞𝗘𝗧 𝗣𝗥𝗢𝗖𝗘𝗦𝗦𝗜𝗡𝗚) ===="

RAAJK20Pro "/proc/sys/net/core/netdev_max_backlog" "4096" "𝗻𝗲𝘁𝗱𝗲𝘃_𝗺𝗮𝘅_𝗯𝗮𝗰𝗸𝗹𝗼𝗴" "$NETWORK"
RAAJK20Pro "/proc/sys/net/core/rmem_default" "262144" "𝗿𝗺𝗲𝗺_𝗱𝗲𝗳𝗮𝘂𝗹𝘁" "$NETWORK"
RAAJK20Pro "/proc/sys/net/core/rmem_max" "524288" "𝗿𝗺𝗲𝗺_𝗺𝗮𝘅" "$NETWORK"
RAAJK20Pro "/proc/sys/net/core/wmem_default" "262144" "𝘄𝗺𝗲𝗺_𝗱𝗲𝗳𝗮𝘂𝗹𝘁" "$NETWORK"
RAAJK20Pro "/proc/sys/net/core/wmem_max" "524288" "𝘄𝗺𝗲𝗺_𝗺𝗮𝘅" "$NETWORK"
RAAJK20Pro "/proc/sys/net/core/somaxconn" "4096" "𝘀𝗼𝗺𝗮𝘅𝗰𝗼𝗻𝗻" "$NETWORK"
RAAJK20Pro "/proc/sys/net/core/optmem_max" "204800" "𝗼𝗽𝘁𝗺𝗲𝗺_𝗺𝗮𝘅" "$NETWORK"

log "====𝗧𝗖𝗣 𝗨𝗟𝗧𝗥𝗔-𝗥𝗘𝗦𝗣𝗢𝗡𝗦𝗜𝗩𝗘 𝗠𝗢𝗗𝗘===="

RAAJK20Pro "/proc/sys/net/ipv4/tcp_slow_start_after_idle" "0" "𝘁𝗰𝗽_𝘀𝗹𝗼𝘄_𝘀𝘁𝗮𝗿𝘁_𝗮𝗳𝘁𝗲𝗿_𝗶𝗱𝗹𝗲" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_low_latency" "1" "𝘁𝗰𝗽_𝗹𝗼𝘄_𝗹𝗮𝘁𝗲𝗻𝗰𝘆" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_timestamps" "1" "𝘁𝗰𝗽_𝘁𝗶𝗺𝗲𝘀𝘁𝗮𝗺𝗽𝘀" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_sack" "1" "𝘁𝗰𝗽_𝘀𝗮𝗰𝗸" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_fack" "1" "𝘁𝗰𝗽_𝗳𝗮𝗰𝗸" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_window_scaling" "1" "𝘁𝗰𝗽_𝘄𝗶𝗻𝗱𝗼𝘄_𝘀𝗰𝗮𝗹𝗶𝗻𝗴" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_moderate_rcvbuf" "1" "𝘁𝗰𝗽_𝗺𝗼𝗱𝗲𝗿𝗮𝘁𝗲_𝗿𝗰𝘃𝗯𝘂𝗳" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_no_metrics_save" "0" "𝘁𝗰𝗽_𝗻𝗼_𝗺𝗲𝘁𝗿𝗶𝗰𝘀_𝘀𝗮𝘃𝗲" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_ecn" "1" "𝘁𝗰𝗽_𝗲𝗰𝗻 (Explicit Congestion Notification)" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_adv_win_scale" "1" "𝗔𝗱𝘃_𝘄𝗶𝗻_𝘀𝗰𝗮𝗹𝗲" "$TCP"


TCP_CC_FILE="/proc/sys/net/ipv4/tcp_congestion_control"
AVAILABLE_CC=$(cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null)
PREFERRED_TCP_ALGOS="bbr2 bbr westwood cubic reno"

for algo in $PREFERRED_TCP_ALGOS; do
    if echo "$AVAILABLE_CC" | grep -qw "$algo"; then
        RAAJK20Pro "$TCP_CC_FILE" "$algo" "𝗧𝗖𝗣_𝗔𝗟𝗚𝗢𝗥𝗜𝗧𝗛𝗠 ➜ $algo" "$TCP"
        break
    fi
done

log "====𝗖𝗢𝗡𝗡𝗘𝗖𝗧𝗜𝗢𝗡 𝗧𝗜𝗠𝗘𝗢𝗨𝗧 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗔𝗧𝗜𝗢𝗡𝗦===="
RAAJK20Pro "/proc/sys/net/ipv4/tcp_syn_retries" "3" "𝘁𝗰𝗽_𝘀𝘆𝗻_𝗿𝗲𝘁𝗿𝗶𝗲𝘀" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_synack_retries" "2" "𝘁𝗰𝗽_𝘀𝘆𝗻𝗮𝗰𝗸_𝗿𝗲𝘁𝗿𝗶𝗲𝘀" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_retries2" "3" "𝘁𝗰𝗽_𝗿𝗲𝘁𝗿𝗶𝗲𝘀𝟮" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_fin_timeout" "15" "𝘁𝗰𝗽_𝗳𝗶𝗻_𝘁𝗶𝗺𝗲𝗼𝘂𝘁" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/ip_local_port_range" "1024 65535" "𝗽𝗼𝗿𝘁_𝗿𝗮𝗻𝗴𝗲_𝗯𝗼𝗼𝘀𝘁" "$TCP"

log "====𝗦𝗢𝗖𝗞𝗘𝗧 𝗕𝗨𝗙𝗙𝗘𝗥𝗦 (𝗙𝗔𝗦𝗧𝗘𝗥 𝗣𝗔𝗖𝗞𝗘𝗧 𝗧𝗥𝗔𝗡𝗦𝗙𝗘𝗥)===="
RAAJK20Pro "/proc/sys/net/ipv4/tcp_rmem" "4096 87380 524288" "𝘁𝗰𝗽_𝗿𝗺𝗲𝗺" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_wmem" "4096 65536 524288" "𝘁𝗰𝗽_𝘄𝗺𝗲𝗺" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/udp_rmem_min" "8192" "𝘂𝗱𝗽_𝗿𝗺𝗲𝗺_𝗺𝗶𝗻" "$UDP"
RAAJK20Pro "/proc/sys/net/ipv4/udp_wmem_min" "8192" "𝘂𝗱𝗽_𝘄𝗺𝗲𝗺_𝗺𝗶𝗻" "$UDP"

log "====𝗙𝗔𝗦𝗧 𝗖𝗢𝗡𝗡𝗘𝗖𝗧𝗜𝗢𝗡 𝗥𝗘𝗨𝗦𝗘 (𝗟𝗘𝗦𝗦 𝗗𝗘𝗟𝗔𝗬)===="
RAAJK20Pro "/proc/sys/net/ipv4/tcp_tw_reuse" "1" "𝘁𝗰𝗽_𝘁𝘄_𝗿𝗲𝘂𝘀𝗲" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_max_tw_buckets" "262144" "𝘁𝗰𝗽_𝗺𝗮𝘅_𝘁𝘄_𝗯𝘂𝗰𝗸𝗲𝘁𝘀" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_max_syn_backlog" "8192" "𝘁𝗰𝗽_𝗺𝗮𝘅_𝘀𝘆𝗻_𝗯𝗮𝗰𝗸𝗹𝗼𝗴" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_fastopen" "1" "𝘁𝗰𝗽_𝗳𝗮𝘀𝘁𝗼𝗽𝗲𝗻" "$TCP"

log "====𝗔𝗥𝗣 𝗖𝗔𝗖𝗛𝗘 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗔𝗧𝗜𝗢𝗡 (𝗙𝗔𝗦𝗧𝗘𝗥 𝗟𝗢𝗖𝗔𝗟 𝗡𝗘𝗧𝗪𝗢𝗥𝗞)===="
RAAJK20Pro "/proc/sys/net/ipv4/neigh/default/gc_thresh1" "1024" "𝗴𝗰_𝘁𝗵𝗿𝗲𝘀𝗵𝟭" "$NETWORK"
RAAJK20Pro "/proc/sys/net/ipv4/neigh/default/gc_thresh2" "2048" "𝗴𝗰_𝘁𝗵𝗿𝗲𝘀𝗵𝟮" "$NETWORK"
RAAJK20Pro "/proc/sys/net/ipv4/neigh/default/gc_thresh3" "4096" "𝗴𝗰_𝘁𝗵𝗿𝗲𝘀𝗵𝟯" "$NETWORK"

log "====𝗦𝗘𝗖𝗨𝗥𝗜𝗧𝗬 𝗧𝗪𝗘𝗔𝗞𝗦 (𝗡𝗢 𝗣𝗘𝗥𝗙𝗢𝗥𝗠𝗔𝗡𝗖𝗘 𝗟𝗢𝗦𝗦)===="
RAAJK20Pro "/proc/sys/net/ipv4/tcp_syncookies" "1" "𝘁𝗰𝗽_𝘀𝘆𝗻𝗰𝗼𝗼𝗸𝗶𝗲𝘀" "$SECURITY"
RAAJK20Pro "/proc/sys/net/ipv4/conf/all/rp_filter" "0" "𝗿𝗽_𝗳𝗶𝗹𝘁𝗲𝗿" "$SECURITY"
RAAJK20Pro "/proc/sys/net/ipv4/icmp_echo_ignore_all" "0" "𝗶𝗰𝗺𝗽_𝗲𝗰𝗵𝗼_𝗶𝗴𝗻𝗼𝗿𝗲_𝗮𝗹𝗹" "$SECURITY"

log "==== 𝗨𝗡𝗜𝗫 𝗦𝗢𝗖𝗞𝗘𝗧 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗔𝗧𝗜𝗢𝗡 ===="
RAAJK20Pro "/proc/sys/net/unix/max_dgram_qlen" "4096" "𝗺𝗮𝘅_𝗱𝗴𝗿𝗮𝗺_𝗾𝗹𝗲𝗻" "$NETWORK"

log "===𝗠𝗧𝗨 𝗢𝗽𝘁𝗶𝗺𝗶𝘇𝗮𝘁𝗶𝗼𝗻 (𝗟𝗢𝗪 𝗟𝗔𝗧𝗘𝗡𝗖𝗬 𝗚𝗔𝗠𝗜𝗡𝗚)==="

# Set MTU for Wi-Fi
for iface in $(ls /sys/class/net/ | grep -E 'wlan|rmnet|ccmni|radio'); do
  if [ -e "/sys/class/net/$iface/mtu" ]; then
    RAAJK20Pro "/sys/class/net/$iface/mtu" "1400" "𝗠𝗧𝗨_𝗦𝗘𝗧 ➜ $iface" "$NETWORK"
  fi
done

if ! grep -q "𝗠𝗧𝗨_𝗦𝗘𝗧" "$LOG_FILE"; then
  log "$WARNING No valid MTU interfaces were updated"
fi

log "===𝗦𝗵𝗼𝗿𝘁 𝗗𝗡𝗦 𝗧𝗧𝗟 (𝗳𝗮𝘀𝘁𝗲𝗿 𝗗𝗡𝗦 𝘂𝗽𝗱𝗮𝘁𝗲𝘀, 𝗮𝘃𝗼𝗶𝗱 𝘀𝘁𝗮𝗹𝗲 𝗰𝗮𝗰𝗵𝗲)==="
RAAJK20Pro "/proc/sys/net/ipv4/ipfrag_time" "10" "𝗶𝗽𝗳𝗿𝗮𝗴_𝘁𝗶𝗺𝗲" "$NETWORK"

log "===𝗔𝗴𝗴𝗿𝗲𝘀𝘀𝗶𝘃𝗲 𝗧𝗖𝗣 𝗙𝗜𝗡 𝗖𝗹𝗲𝗮𝗻𝘂𝗽==="
RAAJK20Pro "/proc/sys/net/ipv4/tcp_orphan_retries" "2" "𝘁𝗰𝗽_𝗼𝗿𝗽𝗵𝗮𝗻_𝗿𝗲𝘁𝗿𝗶𝗲𝘀" "$TCP"
RAAJK20Pro "/proc/sys/net/ipv4/tcp_max_orphans" "4096" "𝘁𝗰𝗽_𝗺𝗮𝘅_𝗼𝗿𝗽𝗵𝗮𝗻𝘀" "$TCP"

RAAJK20Pro "/proc/sys/net/ipv4/udp_mem" "8192 65536 524288" "𝘂𝗱𝗽_𝗺𝗲𝗺_𝘁𝘂𝗻𝗲" "$UDP"

log "====𝗙𝗟𝗨𝗦𝗛 𝗥𝗢𝗨𝗧𝗘𝗦 & 𝗖𝗟𝗘𝗔𝗥 𝗖𝗔𝗖𝗛𝗘===="
RAAJK20Pro "/proc/sys/net/ipv4/route/flush" "1" "𝗳𝗹𝘂𝘀𝗵" "$NETWORK"

) 9>/data/local/tmp/KernelEnhancer.lock

# ========== VERIFY PRIMARY LOG ==========
if [ ! -s "$LOG_FILE" ]; then
  echo "[$(date '+%Y-%m-%d %I:%M %p')] ⚠️ Primary log file is empty—dumping diagnostics" >> "$EMERGENCY_LOG"
  echo "Permissions:" "$(ls -ld "$(dirname "$LOG_FILE")" "$(dirname "$SDCARD_LOG")")" >> "$EMERGENCY_LOG"
  echo "Storage:" "$(df -h /data /sdcard)" >> "$EMERGENCY_LOG"
  echo "SELinux:" "$(dmesg | grep avc | tail -5)" >> "$EMERGENCY_LOG"
fi

# =============================================
# FINALIZATION
# =============================================

log "=== 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗔𝗧𝗜𝗢𝗡 𝗦𝗨𝗠𝗠𝗔𝗥𝗬 ==="
log "Successful tweaks: $(grep -c "$SUCCESS" "$LOG_FILE")"
log "Unsupported features: $(grep -c "$UNSUPPORTED" "$LOG_FILE")"
log "Failed attempts: $(grep -c "$FAILED" "$LOG_FILE")"
log ""
log "=== 𝗧𝗖𝗣 𝗧𝗪𝗘𝗔𝗞𝗦 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘𝗗 ✔️ ==="
log "== 𝗔𝘂𝘁𝗵𝗼𝗿: (@RAAJK20Pro) =="
log "== 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺:- https://t.me/KernelEnhancer =="
log "Finished at $(date)"

# ========== COPY LOG TO SDCARD ==========
if [ -d "/sdcard" ] && [ -w "/sdcard" ]; then
  cp "$LOG_FILE" "$SDCARD_LOG" && chmod 666 "$SDCARD_LOG"
  echo "[$(date '+%Y-%m-%d %I:%M %p')] 📁 Log copied to $SDCARD_LOG" >> "$LOG_FILE"
else
  echo "[$(date '+%Y-%m-%d %I:%M %p')] ⚠️ Failed to copy log to /sdcard — not writable" >> "$EMERGENCY_LOG"
  echo "Storage info: $(df -h /sdcard 2>/dev/null)" >> "$EMERGENCY_LOG"
fi

# ========== EMERGENCY LOG FINAL STATUS ==========
if [ ! -s "$EMERGENCY_LOG" ]; then
  echo "[$(date '+%Y-%m-%d %I:%M %p')] ✅ SYSTEM STATUS: No failures detected during execution" >> "$EMERGENCY_LOG"
else
  echo "[$(date '+%Y-%m-%d %I:%M %p')] ⚠️ SYSTEM STATUS: Review above errors" >> "$EMERGENCY_LOG"
fi

exit 0