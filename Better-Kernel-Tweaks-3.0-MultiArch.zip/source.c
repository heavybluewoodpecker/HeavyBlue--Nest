// Telegram: @RiProG | Channel: @RiOpSo | Group: @RiOpSoDisc
// Don't use or modify this code without permission

#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

void write_value(const char *path, long long value) {
  FILE *file = fopen(path, "w");
  if (file) {
    fprintf(file, "%lld", value);
    fclose(file);
  }
}

void write_string(const char *path, const char *value) {
  FILE *file = fopen(path, "w");
  if (file) {
    fputs(value, file);
    fclose(file);
  }
}

void apply_kernel_tweaks() {
  write_value("/proc/sys/kernel/perf_cpu_time_max_percent", 3);
  write_value("/proc/sys/kernel/sched_autogroup_enabled", 1);
  write_value("/proc/sys/kernel/sched_child_runs_first", 0);
  write_value("/proc/sys/kernel/sched_tunable_scaling", 0);
  write_value("/proc/sys/kernel/sched_latency_ns", 4000000);
  write_value("/proc/sys/kernel/sched_min_granularity_ns", 100000);
  write_value("/proc/sys/kernel/sched_wakeup_granularity_ns", 2000000);
  write_value("/proc/sys/kernel/sched_migration_cost_ns", 5000000);
  write_value("/proc/sys/kernel/sched_nr_migrate", 128);
  write_value("/proc/sys/kernel/sched_schedstats", 0);
  write_value("/proc/sys/kernel/random/read_wakeup_threshold", 64);
  write_value("/proc/sys/kernel/random/write_wakeup_threshold", 128);
  write_value("/proc/sys/kernel/panic", 0);
  write_value("/proc/sys/kernel/panic_on_oops", 0);
  write_string("/proc/sys/kernel/printk_devkmsg", "off");
}

void apply_vm_tweaks() {
  write_value("/proc/sys/vm/dirty_background_ratio", 15);
  write_value("/proc/sys/vm/dirty_ratio", 30);
  write_value("/proc/sys/vm/dirty_expire_centisecs", 3000);
  write_value("/proc/sys/vm/dirty_writeback_centisecs", 3000);
  write_value("/proc/sys/vm/page-cluster", 0);
  write_value("/proc/sys/vm/stat_interval", 10);
  write_value("/proc/sys/vm/swappiness", 40);
  write_value("/proc/sys/vm/vfs_cache_pressure", 80);
  write_value("/proc/sys/vm/overcommit_ratio", 80);
  write_value("/proc/sys/vm/extra_free_kbytes", 10240);
  write_value("/proc/sys/vm/panic_on_oom", 0);
}

void apply_cpu_tweaks() {
  char cpudir[256], governor[32], pathbuf[256];
  for (int cpu = 0; cpu < 8; cpu++) {
    snprintf(cpudir, sizeof(cpudir), "/sys/devices/system/cpu/cpu%d/cpufreq",
             cpu);
    snprintf(pathbuf, sizeof(pathbuf), "%s/scaling_available_governors",
             cpudir);
    FILE *gov_file = fopen(pathbuf, "r");
    if (!gov_file)
      break;
    fscanf(gov_file, "%31s", governor);
    fclose(gov_file);
    char kernel_type[8] = "";
    if (strstr(governor, "schedutil"))
      strcpy(kernel_type, "EAS");
    else if (strstr(governor, "interactive"))
      strcpy(kernel_type, "HMP");
    snprintf(pathbuf, sizeof(pathbuf), "%s/scaling_governor", cpudir);
    write_string(pathbuf, kernel_type[0] ? kernel_type : "schedutil");
    write_value(pathbuf, 1500);
    write_value(pathbuf, 85);
    write_value(pathbuf, kernel_type[0] ? 1728000 : 1497600);
  }
}

void apply_io_tweaks() {
  char queuedir[256], sched_path[256], scheduler[32];
  for (int i = 0; i < 4; i++) {
    snprintf(queuedir, sizeof(queuedir), "/sys/block/sd%c/queue", 'a' + i);
    snprintf(sched_path, sizeof(sched_path), "%s/scheduler", queuedir);
    FILE *sched_file = fopen(sched_path, "r");
    if (!sched_file)
      break;
    fscanf(sched_file, "%31s", scheduler);
    fclose(sched_file);
    write_string(sched_path, strstr(scheduler, "bfq") ? "bfq" : "mq-deadline");
    snprintf(sched_path, sizeof(sched_path), "%s/read_ahead_kb", queuedir);
    write_value(sched_path, 64);
    snprintf(sched_path, sizeof(sched_path), "%s/nr_requests", queuedir);
    write_value(sched_path, 256);
  }
}

void apply_network_tweaks() {
  char congestion[32];
  FILE *cong_file =
      fopen("/proc/sys/net/ipv4/tcp_available_congestion_control", "r");
  if (cong_file) {
    fscanf(cong_file, "%31s", congestion);
    fclose(cong_file);
    write_string("/proc/sys/net/ipv4/tcp_congestion_control",
                 strstr(congestion, "bbr")        ? "bbr"
                 : strstr(congestion, "cubic")    ? "cubic"
                 : strstr(congestion, "westwood") ? "westwood"
                                                  : "reno");
    write_value("/proc/sys/net/ipv4/tcp_ecn", 1);
    write_value("/proc/sys/net/ipv4/tcp_fastopen", 3);
    write_value("/proc/sys/net/ipv4/tcp_syncookies", 0);
  }
}

void apply_sched_features() {
  write_string("/sys/kernel/debug/sched_features", "NEXT_BUDDY\n");
  write_string("/sys/kernel/debug/sched_features", "TTWU_QUEUE\n");
  write_string("/sys/kernel/debug/sched_features", "NO_HRTICK\n");
  write_string("/sys/kernel/debug/sched_features", "WAKEUP_PREEMPTION\n");
}

void apply_schedtune_tweaks() {
  write_value("/dev/stune/top-app/schedtune.prefer_idle", 0);
  write_value("/dev/stune/top-app/schedtune.boost", 1);
}

int main() {
  printf("\nTelegram: @RiProG | Channel: @RiOpSo | Group: @RiOpSoDisc\n\n");
  int null_fd = open("/dev/null", O_WRONLY);
  if (null_fd != -1) {
    dup2(null_fd, STDOUT_FILENO);
    dup2(null_fd, STDERR_FILENO);
    close(null_fd);
  }
  apply_kernel_tweaks();
  apply_vm_tweaks();
  apply_cpu_tweaks();
  apply_io_tweaks();
  apply_network_tweaks();
  apply_sched_features();
  apply_schedtune_tweaks();
  return 0;
}