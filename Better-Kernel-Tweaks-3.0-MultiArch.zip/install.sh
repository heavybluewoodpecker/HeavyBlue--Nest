#!/bin/sh
SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true
REPLACE=""
sleep 2
ui_print ""
ui_print "Author:"
ui_print "  Telegram: @RiProG | Channel: @RiOpSo | Group: @RiOpSoDisc"
ui_print ""
sleep 2
ui_print "- Extracting module files"
unzip -o "$ZIPFILE" 'source.c' -d "$MODPATH" >&2
architecture=$(getprop ro.product.cpu.abi)
if [ "$architecture" = "arm64-v8a" ]; then
	ui_print "- Architecture $architecture is supported."
	ui_print "- Installation continues."
	unzip -p "$ZIPFILE" 'arm64' >"$MODPATH/BKT"
elif [ "$architecture" = "armeabi-v7a" ]; then
	ui_print "- Architecture $architecture is supported."
	ui_print "- Installation continues."
	unzip -p "$ZIPFILE" 'arm' >"$MODPATH/BKT"
else
	ui_print "- Architecture $architecture is not supported."
	ui_print "- Installation aborted."
	exit 1
fi
chmod +x "$MODPATH/BKT"
