#!/system/bin/sh
# Wait for boot complete
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
done

# Launch gameon
nohup vulkan3 >/dev/null 2>&1 &