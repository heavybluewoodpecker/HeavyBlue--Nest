#!/system/bin/sh

RAM_TOTAL_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
RAM_FREE_KB=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
RAM_TOTAL_GB=$(( (RAM_TOTAL_KB + 1048576 - 1) / 1048576 ))
RAM_FREE_GB=$(( (RAM_FREE_KB + 1048576 - 1) / 1048576 ))

get_cpu_codename() {
  local codename=$(getprop ro.mediatek.platform)
  [ -z "$codename" ] && codename=$(getprop ro.board.platform)
  [ -z "$codename" ] && codename=$(grep -m1 'Hardware' /proc/cpuinfo | cut -d ':' -f2 | sed 's/^[ \t]*//')
  echo "${codename:-unknown}"
}
ui_print "=========================================="
ui_print "  _   ____  ____   __ _____   _  __"
ui_print " | | / / / / / /  / //_/ _ | / |/ /"
ui_print " | |/ / /_/ / /__/ ,< / __ |/    / "
ui_print " |___/\\____/____/_/|_/_/ |_/_/|_/  "
ui_print " / __ \\/ _ \\/_  __/                "
ui_print "/ /_/ / ___/ / /                   "
ui_print "\\____/_/    /_/                    "
ui_print "                                   "
ui_print "=========================================="
ui_print " "
ui_print "DEVICE       : $(getprop ro.build.product)"
ui_print "MODEL        : $(getprop ro.product.model)"
ui_print "MANUFACTURER : $(getprop ro.product.system.manufacturer)"
ui_print "BOARD        : $(getprop ro.product.board)"
ui_print "CODENAME     : $(get_cpu_codename)"
ui_print "ANDROID VER  : $(getprop ro.build.version.release)"
ui_print "🧠 RAM       : ${RAM_TOTAL_GB} GB total / ${RAM_FREE_GB} GB free"
ui_print "KERNEL       : $(uname -r)"
ui_print " "
sleep 1.2
case "$((RANDOM % 12 + 1))" in
  1)  ui_print "- Vulkan render optimization activated." ;;
  2)  ui_print "- Smooth frames, stable power. Vulkan ready." ;;
  3)  ui_print "- Boosting GPU paths for seamless Vulkan." ;;
  4)  ui_print "- Adaptive tuning for Vulkan workloads." ;;
  5)  ui_print "- Low latency, high stability. Vulkan focused." ;;
  6)  ui_print "- Rendering performance enhanced via Vulkan." ;;
  7)  ui_print "- Optimized GPU threads for Vulkan apps." ;;
  8)  ui_print "- Maximum efficiency for Vulkan pipelines." ;;
  9)  ui_print "- Cleaner frames, smoother experience. Vulkan tuned." ;;
  10) ui_print "- Vulkan rendering refined for peak smoothness." ;;
  11) ui_print "- GPU fine-tuned for modern Vulkan engines." ;;
  12) ui_print "- System prepared for advanced Vulkan rendering." ;;
esac

# Footer
ui_print " "
ui_print "=========================================="
ui_print "[✓] Vulkan Layers Activated Successfully"
ui_print "=========================================="