#!/system/bin/sh
MODULE_DIR="/data/adb/modules/snapzen"

while IFS=: read -r cpu gov min max; do
    echo "schedutil" > /sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_governor
    echo $(( (max + min) / 2 )) > /sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_max_freq
done < "$MODULE_DIR/cpu_profiles.txt"

if [ -f "$MODULE_DIR/gpu_profile.txt" ]; then
    IFS=: read -r type gmin gmax < "$MODULE_DIR/gpu_profile.txt"
    echo $(( (gmax + gmin) / 2 )) > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
fi
