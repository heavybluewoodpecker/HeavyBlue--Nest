#!/system/bin/sh

MODULE_DIR="/data/adb/modules/snapzen"
LOG_FILE="/data/local/tmp/snapzen.log"

# ------------------------
# CONFIGURABLE THRESHOLDS
# ------------------------
COOL_TEMP=42     # Di bawah ini = dingin (Gaming mode)
HOT_TEMP=55      # Di atas ini = panas (Battery mode)
CPU_LOAD_HIGH=80 # CPU usage > 80% dianggap berat

# ------------------------
# SMART THERMAL SCANNER
# ------------------------
MAX_TEMP=0
for zone in /sys/class/thermal/thermal_zone*; do
    type=$(cat "$zone/type" 2>/dev/null)
    temp_raw=$(cat "$zone/temp" 2>/dev/null)
    
    [ -z "$temp_raw" ] && continue
    [ "$temp_raw" -gt "$MAX_TEMP" ] && MAX_TEMP=$temp_raw
done

TEMP_C=$((MAX_TEMP / 1000))
echo "[SnapZen] 🔥 MaxTemp: ${TEMP_C}°C" >> "$LOG_FILE"

# ------------------------
# CPU LOAD CALCULATION (accurate)
# ------------------------
read cpu user nice system idle iowait irq softirq steal guest guest_nice < /proc/stat
total1=$((user + nice + system + idle + iowait + irq + softirq + steal))
idle1=$((idle + iowait))
sleep 1
read cpu user2 nice2 system2 idle2 iowait2 irq2 softirq2 steal2 guest2 guest_nice2 < /proc/stat
total2=$((user2 + nice2 + system2 + idle2 + iowait2 + irq2 + softirq2 + steal2))
idle2=$((idle2 + iowait2))

delta_total=$((total2 - total1))
delta_idle=$((idle2 - idle1))

CPU_USAGE=$((100 * (delta_total - delta_idle) / delta_total))
echo "[SnapZen] ⚙️ CPU Usage: $CPU_USAGE%" >> "$LOG_FILE"

# ------------------------
# DECISION TREE
# ------------------------
if [ "$TEMP_C" -ge "$HOT_TEMP" ]; then
    echo "[SnapZen] 🧊 Switching to Battery Mode (Too Hot)" >> "$LOG_FILE"
    sh "$MODULE_DIR/scripts/apply_battery.sh"
elif [ "$TEMP_C" -le "$COOL_TEMP" ] && [ "$CPU_USAGE" -ge "$CPU_LOAD_HIGH" ]; then
    echo "[SnapZen] 🚀 Switching to Gaming Mode (Cool & High Load)" >> "$LOG_FILE"
    sh "$MODULE_DIR/scripts/apply_gaming.sh"
else
    echo "[SnapZen] 🌿 Switching to Balanced Mode" >> "$LOG_FILE"
    sh "$MODULE_DIR/scripts/apply_balanced.sh"
fi