#!/system/bin/sh
MODULE_DIR="/data/adb/modules/snapzen"

while IFS=: read -r cpu gov min max; do
    echo "performance" > /sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_governor
    echo $max > /sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_max_freq
done < "$MODULE_DIR/cpu_profiles.txt"

if [ -f "$MODULE_DIR/gpu_profile.txt" ]; then
    IFS=: read -r type gmin gmax < "$MODULE_DIR/gpu_profile.txt"
    echo $gmax > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
    echo 1 > /sys/class/kgsl/kgsl-3d0/force_clk_on
    echo 1 > /sys/class/kgsl/kgsl-3d0/force_bus_on
    echo 0 > /sys/class/kgsl/kgsl-3d0/idlemgr_enable
fi
