#!/system/bin/sh

MODULE_DIR="/data/adb/modules/snapzen"
LOG_FILE="/data/local/tmp/snapzen.log"

echo "[SnapZen] Initializing..." > "$LOG_FILE"

# CPU Scan
rm -f "$MODULE_DIR/cpu_profiles.txt"
for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
    [ -d "$cpu" ] || continue
    cpu_num=$(echo "$cpu" | grep -o '[0-9]*')
    gov=$(cat $cpu/scaling_governor 2>/dev/null)
    min=$(cat $cpu/cpuinfo_min_freq 2>/dev/null)
    max=$(cat $cpu/cpuinfo_max_freq 2>/dev/null)
    echo "$cpu_num:$gov:$min:$max" >> "$MODULE_DIR/cpu_profiles.txt"
    echo "[CPU] $cpu_num Gov=$gov Min=$min Max=$max" >> "$LOG_FILE"
done

# GPU Scan
rm -f "$MODULE_DIR/gpu_profile.txt"
if [ -d "/sys/class/kgsl/kgsl-3d0" ]; then
    gmin=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/min_freq 2>/dev/null)
    gmax=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/max_freq 2>/dev/null)
    echo "adreno:$gmin:$gmax" > "$MODULE_DIR/gpu_profile.txt"
    echo "[GPU] Adreno Min=$gmin Max=$gmax" >> "$LOG_FILE"
fi

echo "[SnapZen] Init Complete" >> "$LOG_FILE"
