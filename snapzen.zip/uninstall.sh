#!/system/bin/sh

MODDIR="/data/adb/modules/snapzen"
LOGFILE="/data/local/tmp/snapzen.log"

echo "[SnapZen] 🗑 Starting uninstallation..." > "$LOGFILE"

# Kill running service (if exists)
pkill -f "$MODDIR/scripts/autoswitch.sh"
pkill -f "$MODDIR/service.sh"

# Restore CPU/GPU to system defaults (optional safe fallback)
echo "[SnapZen] Restoring system default governors..." >> "$LOGFILE"

for cpu_path in /sys/devices/system/cpu/cpu*/cpufreq; do
    [ -d "$cpu_path" ] || continue
    echo "schedutil" > "$cpu_path/scaling_governor" 2>/dev/null
done

if [ -d "/sys/class/kgsl/kgsl-3d0" ]; then
    echo 1 > /sys/class/kgsl/kgsl-3d0/idlemgr_enable 2>/dev/null
    echo 0 > /sys/class/kgsl/kgsl-3d0/force_clk_on 2>/dev/null
    echo 0 > /sys/class/kgsl/kgsl-3d0/force_bus_on 2>/dev/null
fi

# Remove module folder
rm -rf "$MODDIR"

# Clean log
rm -f "$LOGFILE"

echo "[SnapZen] ✅ Uninstall complete. Back to stock behavior." >> "$LOGFILE"