#!/system/bin/sh

MODDIR="/data/adb/modules/snapzen"
LOGFILE="/data/local/tmp/snapzen.log"

# Optional: Delay to let system stabilize after boot
sleep 5

# Log startup
echo "[SnapZen] 🌀 Starting service.sh..." > "$LOGFILE"

# Check for uninstall trigger
if [ -f "$MODDIR/uninstall.sh" ] && [ -f "/data/local/tmp/snapzen_disable" ]; then
    echo "[SnapZen] 🚨 Uninstall trigger detected. Executing uninstall..." >> "$LOGFILE"
    sh "$MODDIR/uninstall.sh"
    exit 0
fi

# Auto-chmod all core scripts (safety check)
[ -f "$MODDIR/init.sh" ] && chmod +x "$MODDIR/init.sh"
[ -f "$MODDIR/snapctl" ] && chmod +x "$MODDIR/snapctl"
[ -d "$MODDIR/scripts" ] && chmod +x "$MODDIR/scripts/"*.sh
[ -f "$MODDIR/uninstall.sh" ] && chmod +x "$MODDIR/uninstall.sh"
[ -f "$MODDIR/customize.sh" ] && chmod +x "$MODDIR/customize.sh"

# Initialize profile detection (CPU/GPU)
sh "$MODDIR/init.sh"

# Infinite autoswitch loop
while true; do
    # Log loop tick
    echo "[SnapZen] 🕒 Tick: $(date)" >> "$LOGFILE"

    # Re-check uninstall flag mid-loop
    if [ -f "$MODDIR/uninstall.sh" ] && [ -f "/data/local/tmp/snapzen_disable" ]; then
        echo "[SnapZen] ⚠️ Uninstall trigger detected during loop. Exiting..." >> "$LOGFILE"
        sh "$MODDIR/uninstall.sh"
        exit 0
    fi

    # Run autoswitch logic (thermal + CPU-aware)
    sh "$MODDIR/scripts/autoswitch.sh"

    # Wait before next check
    sleep 30
done