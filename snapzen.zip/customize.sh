#!/system/bin/sh

MODDIR=${0%/*}
MODNAME="SnapZen"
LOGFILE="/data/local/tmp/snapzen.log"

# Colors
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m'

echo -e "${BLUE}[*] Welcome to $MODNAME Setup Wizard${NC}"
echo -e "${YELLOW}=> Collecting system intel...${NC}"

# Device Info
BRAND=$(getprop ro.product.brand)
MODEL=$(getprop ro.product.model)
DEVICE=$(getprop ro.product.device)
BOARD=$(getprop ro.product.board)
SOC=$(getprop ro.soc.model)
ARCH=$(getprop ro.product.cpu.abi)
ANDROID_VER=$(getprop ro.build.version.release)
SDK_VER=$(getprop ro.build.version.sdk)
KERNEL=$(uname -r)
CPU_MODEL=$(grep "Hardware" /proc/cpuinfo | cut -d ':' -f2 | sed 's/^ //')

# Print Summary
echo -e "${GREEN}✔ Brand: $BRAND"
echo -e "✔ Model: $MODEL"
echo -e "✔ Device Code: $DEVICE"
echo -e "✔ SoC: ${SOC:-$BOARD}"
echo -e "✔ CPU: $CPU_MODEL"
echo -e "✔ Arch: $ARCH"
echo -e "✔ Android: $ANDROID_VER (SDK $SDK_VER)"
echo -e "✔ Kernel: $KERNEL${NC}"

# Snapdragon Check
if echo "$SOC $BOARD $CPU_MODEL" | grep -iq "qualcomm"; then
    echo -e "${GREEN}[✓] Snapdragon detected. Performance tuning mode enabled.${NC}"
else
    echo -e "${YELLOW}[!] Warning: Non-Snapdragon chip detected. Proceed at your own risk.${NC}"
fi

# Module Activation
echo -e "${BLUE}[*] Initializing SnapZen kernel interface...${NC}"
sh $MODDIR/init.sh

# Done
echo -e "${GREEN}[✓] Initialization complete. SnapZen is ready to adapt and dominate.${NC}"
echo "[SnapZen] Customize complete on $MODEL ($DEVICE)" >> "$LOGFILE"