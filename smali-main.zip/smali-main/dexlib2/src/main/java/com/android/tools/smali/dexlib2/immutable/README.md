## About
This folder contains classes that originally relied on Guava based Immutable collections, thus the
naming. The current implementations rely on the Java unmodifiable collections or on constructor
helpers that produce immutable collections from Java Collections.